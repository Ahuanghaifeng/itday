package com.infomation.haiffeng.http;

public class Url {
    /**
     * 请求地址
     */
    public static final String BASE_URL = "https://api.douban.com/v2/movie/";

}
