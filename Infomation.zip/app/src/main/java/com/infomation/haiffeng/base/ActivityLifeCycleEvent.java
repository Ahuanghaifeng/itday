package com.infomation.haiffeng.base;

/**
 * Created by helin on 2016/11/11 10:42.
 */

public enum  ActivityLifeCycleEvent {
    CREATE,
    START,
    RESUME,
    PAUSE,
    STOP,
    DESTROY
}
