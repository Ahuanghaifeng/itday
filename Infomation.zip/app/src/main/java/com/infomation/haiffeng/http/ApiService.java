package com.infomation.haiffeng.http;


import com.infomation.haiffeng.enity.HomeLunBo;
import com.infomation.haiffeng.enity.HttpResult;
import com.infomation.haiffeng.enity.Subject;
import com.infomation.haiffeng.enity.UserEntity;

import java.util.List;

import retrofit2.http.GET;
import retrofit2.http.Query;
import rx.Observable;

/**
 * Created by helin on 2016/10/9 17:09.
 */

public interface ApiService {
    @GET("/student/mobileRegister")
    Observable<HttpResult<UserEntity>> login(@Query("phone") String phone, @Query("password") String psw);


    @GET("top250")
    Observable<HttpResult<List<Subject>>> getTopMovie(@Query("start") int start, @Query("count") int count);

    @GET("top250")
    Observable<HttpResult<Subject>> getUser(@Query("touken") String touken);

    @GET("apishouye-slider-mss_88.html")
    Observable<HttpResult<HomeLunBo>> getLunBo();

}
