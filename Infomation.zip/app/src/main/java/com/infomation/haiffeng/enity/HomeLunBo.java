package com.infomation.haiffeng.enity;

import java.util.List;

/**
 * Created by 黄海峰 on 2017/2/15.
 */

public class HomeLunBo {

    /**
     * data : [{"slider_name":"她是中国顶级工笔画家之一，一笔一画勾勒出中国女性的极致美","slider_title":"她是中国顶级工笔画家之一，一笔一画勾勒出中国女性的极致美","images":"https://www.artmss.com/public/images//38/8c/ca/3525153fd149776303c3f9042ca802c4deb217b1.jpg","view_count":"0","sorts":"0","link_type":"3","link_num":"1683","gourl":""},{"slider_name":"2017中央美术学院精微素描精选","slider_title":"2017中央美术学院精微素描精选","images":"https://www.artmss.com/public/images//73/ab/31/94d1de3e6933b9a5aa431e9666a49ec5a32c2bf5.jpg","view_count":"0","sorts":"0","link_type":"3","link_num":"1687","gourl":""},{"slider_name":"中国设计师长脸了！这对小情侣用火锅刷新了外国人对中国设计的看法","slider_title":"中国设计师长脸了！这对小情侣用火锅刷新了外国人对中国设计的看法","images":"https://www.artmss.com/public/images//27/7b/5d/0b55cffb6c6820f2abb255eb9e606ca944580e3b.jpg","view_count":"0","sorts":"0","link_type":"3","link_num":"1659","gourl":""},{"slider_name":"每天都有165万人流着口水向她交作业，这个90后姑娘四年画下千张手绘美食","slider_title":"每天都有165万人流着口水向她交作业，这个90后姑娘四年画下千张手绘美食","images":"https://www.artmss.com/public/images//60/ff/71/f67b9c8501f9652134f045a65dec9753ebd49303-m.jpg?1484118120#w","view_count":"0","sorts":"0","link_type":"1","link_num":"1539","gourl":""}]
     */


    private List<DataBean> data;

    public List<DataBean> getData() {
        return data;
    }

    public void setData(List<DataBean> data) {
        this.data = data;
    }

    public static class DataBean {
        /**
         * slider_name : 她是中国顶级工笔画家之一，一笔一画勾勒出中国女性的极致美
         * slider_title : 她是中国顶级工笔画家之一，一笔一画勾勒出中国女性的极致美
         * images : https://www.artmss.com/public/images//38/8c/ca/3525153fd149776303c3f9042ca802c4deb217b1.jpg
         * view_count : 0
         * sorts : 0
         * link_type : 3
         * link_num : 1683
         * gourl :
         */

        private String slider_name;
        private String slider_title;
        private String images;
        private String view_count;
        private String sorts;
        private String link_type;
        private String link_num;
        private String gourl;

        public String getSlider_name() {
            return slider_name;
        }

        public void setSlider_name(String slider_name) {
            this.slider_name = slider_name;
        }

        public String getSlider_title() {
            return slider_title;
        }

        public void setSlider_title(String slider_title) {
            this.slider_title = slider_title;
        }

        public String getImages() {
            return images;
        }

        public void setImages(String images) {
            this.images = images;
        }

        public String getView_count() {
            return view_count;
        }

        public void setView_count(String view_count) {
            this.view_count = view_count;
        }

        public String getSorts() {
            return sorts;
        }

        public void setSorts(String sorts) {
            this.sorts = sorts;
        }

        public String getLink_type() {
            return link_type;
        }

        public void setLink_type(String link_type) {
            this.link_type = link_type;
        }

        public String getLink_num() {
            return link_num;
        }

        public void setLink_num(String link_num) {
            this.link_num = link_num;
        }

        public String getGourl() {
            return gourl;
        }

        public void setGourl(String gourl) {
            this.gourl = gourl;
        }
    }
}
